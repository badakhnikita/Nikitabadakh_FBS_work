/**
 * 
 */
/**
 * 
 */
module HomeDevice {
}