package model;

public interface KitchenDevice {

}
