package model;
import java.util.*;
public class House {
ArrayList<Room> rooms=new ArrayList<Room>();

public void addRoom(Room r)
{
	rooms.add(r);
}
	
public ArrayList<Room> getRooms()
{
	return rooms;
}
}
