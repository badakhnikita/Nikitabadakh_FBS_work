package model;

public class Ac extends Device implements ControllableDevice,TemperatueDevice,BedroomDevice,HallDevice
{
	int temp;
	public Ac(String id,String name)
	{
		super(id,name);
		this.temp=24;
	}
	public String getDeviceType()
	{
		return "Ac";
	}
	public void increaseTemp()
	{
		if(temp<30)
		{
			temp++;
		}
	}
	public void decreaseTemp()
	{
		if(temp>16)
		{
			temp--;
		}
	}
	int getTemp()
	{
		return temp;
	}
	
}