package model;

public interface ControllableDevice {

	void turnOn();
	void turnOff();
	boolean getStatus();
}
