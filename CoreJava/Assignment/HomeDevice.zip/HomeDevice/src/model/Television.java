package model;

public class Television extends Device implements ControllableDevice,EntertainmentDevice,HallDevice,BedroomDevice
{
	int volume;
	int channel;
	public Television(String id,String name)
	{
		super(id,name);
		this.volume=10;
		this.channel=1;
	}
	
	public String getDeviceType()
	{
		return "Television";
	}
	
	public void increaseVolume()
	{
		if(volume<100)
		{
			volume++;
		}
	}
	public void decreaseVolume()
	{
		if(volume>0)
		volume--;
	}
	
	int getVolume()
	{
		return volume;
	}
	void nextChannel()
	{
		channel++;
	}
	
	void previousChannel()
	{
		if(channel>1)
		channel--;
	}
	
	int getChannel()
	{
		return channel;
	}
}

