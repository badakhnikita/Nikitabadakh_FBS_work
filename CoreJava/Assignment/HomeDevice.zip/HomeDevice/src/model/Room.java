package model;
import java.util.ArrayList;
public class Room {
String roomName;
ArrayList<Device> devices=new ArrayList<Device>();
 public Room(String roomName)
 {
	 this.roomName=roomName;
 }
 
 public void addDevice(Device d)
 {
	 devices.add(d);
 }
 public String getRoomName()
 {
	 return roomName;
 }
 public ArrayList<Device> getDevices()
 {
	 return devices;
 }
}

