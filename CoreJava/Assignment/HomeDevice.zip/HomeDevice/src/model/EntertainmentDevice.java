package model;

public interface EntertainmentDevice {

void increaseVolume();
void decreaseVolume();
}
