package model;

public class MusicPlayer extends Device implements ControllableDevice,EntertainmentDevice,HallDevice,KitchenDevice
{
	int volume;
	boolean isPlaying;
	
	public MusicPlayer(String id,String name) {
		super(id,name);
		this.volume=10;
		this.isPlaying=false;
		}
	public String getDeviceType()
	{
		return "MusicPlayer";
	}
	void play()
	{
		if(isOn)
		{
			isPlaying=true;
		}
	}
	
	void pause()
	{
		isPlaying=false;
	}
	
	public void increaseVolume()
	{
		if(volume<100)
		{
			volume++;
		}
	}
	
	public void decreaseVolume()
	{
		if(volume>0)
		{
			volume--;
		}
	}
	
	int getVolume()
	{
		return volume;
	}
	
	boolean isPlaying()
	{
		return isPlaying;
	}
}
