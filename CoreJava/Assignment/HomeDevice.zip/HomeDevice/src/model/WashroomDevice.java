package model;

public interface WashroomDevice {

}
