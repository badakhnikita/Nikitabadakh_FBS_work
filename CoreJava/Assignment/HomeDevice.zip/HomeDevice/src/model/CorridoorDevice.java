package model;
public interface CorridoorDevice {

}
