package model;

public interface TemperatueDevice {
void increaseTemp();
void decreaseTemp();
}
