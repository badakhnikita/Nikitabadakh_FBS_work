package model;

public class Shower extends Device implements ControllableDevice,WashroomDevice
{
	int waterlevel;
	public Shower(String id,String name)
	{
		super(id,name);
		this.waterlevel=1;
	}
	
	public String getDeviceType()
	{
		return "Shower";
	}
	
	void increaseWterLevel()
	{
		if(waterlevel<3)
		{
			waterlevel++;
		}
	}
	
	void decreaseWaterLevel()
	{
		if(waterlevel>1)
		{
			waterlevel--;
		}
	}
	int getWaterLevel()
	{
		return waterlevel;
	}
}

