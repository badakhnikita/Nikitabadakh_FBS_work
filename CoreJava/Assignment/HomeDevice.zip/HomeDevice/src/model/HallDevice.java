package model;

public interface HallDevice {

}
