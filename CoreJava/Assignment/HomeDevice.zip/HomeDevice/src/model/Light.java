package model;

public class Light extends Device implements ControllableDevice,BedroomDevice,HallDevice,KitchenDevice,WashroomDevice,CorridoorDevice
{
	int brightness;
	String color;
	public Light(String id,String name)
	{
		super(id,name);
		this.brightness=50;
		this.color="White";
	}
	public String getDeviceType()
	{
		return "Light";
	}
	
	void increaseBrightness()
	{
		if(brightness<100)
		{
			brightness+=10;
		}
	}
	
	void decreaseBrightness()
	{
		if(brightness>0)
		{
			brightness-=10;
		}
	}
	int getBrightness()
	{
		return brightness;
	}
	void changeColor(String c)
	{
		this.color=c;
	}
	String getColor()
	{
		return color;
	}
}
