package model;

public abstract class Device {
 String deviceId;
 public String deviceName;
 boolean isOn;
 long totalActiveTime;
 long lastOnTime;

 Device(String i,String n )
 {
	 this.deviceId=i;
	 this.deviceName=n;
	 this.isOn=false;
	 this.totalActiveTime=0;
 }
public abstract String getDeviceType();
public void turnOn()
{
	if(!isOn)
	{
		isOn=true;
		lastOnTime=System.currentTimeMillis();
	}
}
 
public void turnOff()
{
	if(isOn)
	{
		isOn=false;
		recordUsageTime();
	}
}

public boolean getStatus()
{
	return isOn;
}
 void recordUsageTime() {
	totalActiveTime+=System.currentTimeMillis()-lastOnTime;
}
 public long getTotalActiveTime()
 {
	 return totalActiveTime;
 }
}
 


 