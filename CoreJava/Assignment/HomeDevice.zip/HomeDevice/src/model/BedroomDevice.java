package model;

public interface BedroomDevice {

}
