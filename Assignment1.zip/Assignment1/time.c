#include<stdio.h>
void main()
{
    int tmin=145;
    int hr,min;
    hr=tmin/60;
    min=tmin%60;
    printf("HOURS AND MINUTES %d %d",hr,min);

}