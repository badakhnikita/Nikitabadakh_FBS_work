#include<stdio.h>
void main()
{
    int a=2,s,c;
    s=a*a;
    c=a*a*a;
    printf("Square and cube of %d is %d %d",a,s,c);
}