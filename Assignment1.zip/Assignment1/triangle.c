#include<stdio.h>
void main()
{
    int b=10;
    int h=20;
    int a;
    a=0.5*(b*h);
    printf("Area of triangle %d",a);
}