#include<stdio.h>
void main()
{
int a,b,c;
a=10;
b=20;
c=a+b;
printf("Addition of %d and %d is %d",a ,b ,c);
}