#include<stdio.h>
void main()
{
int r=5;
int aoc;
aoc=3.14*r*r;
printf("Area of circle %d",aoc);

}