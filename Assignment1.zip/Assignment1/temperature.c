#include<stdio.h>
void main()
{
    int c=40;
    double f;
    f=(c*9/5)+32;
    printf("Temperature in Fahrenheit %lf",f);
}