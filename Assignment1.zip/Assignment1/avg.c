#include<stdio.h>
void main()
{
    int a=10,b=30,c=50,d=60,e=70,avg;
    avg=(a+b+c+d+e)/5;
    printf("Average of five no %d",avg);

}