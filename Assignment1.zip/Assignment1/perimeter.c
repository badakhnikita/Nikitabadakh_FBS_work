#include<stdio.h>
void main()
{
    int l=20;
    int w=30;
    int p;
    p=2*(l+w);
    printf("perimeter of rectangle %d",p);
}